-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2024 at 09:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carservicedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `ID` int(20) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Phone` int(20) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Car_Name` varchar(30) NOT NULL,
  `Price` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`ID`, `Name`, `Phone`, `Address`, `Car_Name`, `Price`) VALUES
(1, 'AungAung', 90099, 'Mawlamyine\r\n', 'Range Rover', 50000);

-- --------------------------------------------------------

--
-- Table structure for table `oil_list`
--

CREATE TABLE `oil_list` (
  `ID` int(20) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Price` int(20) NOT NULL,
  `Img` varchar(30) NOT NULL,
  `Des` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `oil_list`
--

INSERT INTO `oil_list` (`ID`, `Name`, `Price`, `Img`, `Des`) VALUES
(1, 'conventional', 5000, 'oil.jpg', 'Good performance'),
(2, 'Synthetic oil', 8000, 'oil1.jpg', 'Good performance');

-- --------------------------------------------------------

--
-- Table structure for table `rental_car`
--

CREATE TABLE `rental_car` (
  `ID` int(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Phone` int(30) NOT NULL,
  `Img` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rental_car`
--

INSERT INTO `rental_car` (`ID`, `Name`, `Price`, `Phone`, `Img`) VALUES
(2, 'Range Rover', 50000, 697856, 'ran.jpg'),
(3, 'Nssan', 30000, 697856, 'nis.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `ID` int(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Message` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`ID`, `Name`, `Email`, `Message`) VALUES
(1, 'BMW', 'Emma@gmail.com', 'very good service'),
(2, 'Mg Mg', 'Mgmg@gmail.com', 'very very good service');

-- --------------------------------------------------------

--
-- Table structure for table `waterwash`
--

CREATE TABLE `waterwash` (
  `ID` int(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Img` varchar(30) NOT NULL,
  `Time` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `waterwash`
--

INSERT INTO `waterwash` (`ID`, `Name`, `Price`, `Img`, `Time`) VALUES
(1, 'BMW', 30000, 'bmw.jpg', 25),
(3, 'Audi', 30000, 'audi.jpg', 45);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `oil_list`
--
ALTER TABLE `oil_list`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `rental_car`
--
ALTER TABLE `rental_car`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `waterwash`
--
ALTER TABLE `waterwash`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `oil_list`
--
ALTER TABLE `oil_list`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rental_car`
--
ALTER TABLE `rental_car`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `waterwash`
--
ALTER TABLE `waterwash`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
