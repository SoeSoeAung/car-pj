<body>
<center>
<div class="card bg-dark text-white">
  <img src="img/oo.jpg" class="card-img" style='border-radius:20px;' alt="...">
  <div class="card-img-overlay">
    <h3 class="card-title"><i>Oil Changing For Car</i></h3>
    <h4 class="card-text">Our changing oil are high-quality oil and give a nice milage for every car.So you can believe our oil.</h4>
  </div>
</div>

<div class="container">
       <div class="row">
    <?php
error_reporting(1);
include('connection.php');
$data="SELECT * FROM oil_list ORDER BY id DESC";
$val=$con->query($data);
if ($val->num_rows > 0) {
while(list($id,$name,$price,$image) = mysqli_fetch_array($val)){
    echo "<div class='col-4'>
    <div class='card'>
    <img src='admin/img/$image'
    height='300' width='300' style='border-radius:20px;'  />
    <div class='card-content'>
        <h2 >$name</h2>
        <p style='color:green'>Price - $price MMK</p>
      
        <center>  <a href='booking.php?name=$name&price=$price'>
        <img src='img/book.jpg' width=80 class='imageee'/> </a></center>
    </div>
</div>
<br><br>
    </div>";
  
}}else{
    echo "<h1 colspan='8' class='text-center'>
   <b> No data available</b></h1>";
}
?>
</div>
</div>

<div class="text-center p-3 text-white" style="background-color:skyblue">
	&copy 2024 Copyright: Coded By Soe Aung &nbsp;
	<a href="https://www.youtube.com/"><img src="img/fb.jpg" width="20px"></a>
	</div>
</center>
</body>

<style>
  body{
    background-color:#77e7f4 
  }
</style>
