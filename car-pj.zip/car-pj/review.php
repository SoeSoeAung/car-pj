<body>

<center>

<div class="contact-from">
        <div class="form-area">
            <div class="animated fadeInDown">
                <h2 class="yu">Contact Us</h2>
            </div>

            <h2 class="yu"><i>How about our service</i></h2>

            <?php
    error_reporting(1);
    include('connection.php');
    if(isset($_POST['sub'])) {  
        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        // Enclose `order` table name in backticks
        $query = "INSERT INTO `review` VALUES ('', '$name', '$email', '$message')";
        $con->query($query); 
        
        echo "<p style='color:green'>Message Sent Successfully!</p>";
    }
?>

            
            <div class="contact">
                <div class="map animated fadeInLeft">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d61110.04836681045!2d96.05911964863279!3d16.80759250000002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c1ebe4df02ad3b%3A0x182bfb807e42001b!2sA1%20Auto%20Service!5e0!3m2!1sen!2smm!4v1722676494482!5m2!1sen!2smm" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>        
                </div>

                <form method="post" class="yu"><br><br>
                   

                    <label>
                        <input type="text" class="subject" id="subject" name="name" required>
                        <div class="label subject-text">Name</div>
                    </label><br><br>

                    <label>
                        <input type="email" class="email" id="email" name="email" required>
                        <div class="label email-text">E-mail</div>
                    </label><br><br>

                    <label>
                        <textarea class="help-box" id="helpBox" cols="30" rows="5" required name="message"></textarea>
                        <div class="label help-text">Message</div>
                    </label><br><br>

                   <div class="row">
                        <div class="col-4"></div>
                        <div class="col-4">
                        <input type="submit" value="Submit" name="sub" class="btn btn-outline-info" >
                        </div>
                        <div class="col-4"></div>
                   </div>   
                </form>
            </div>
        </div>
    </div>

</center>

<div class="text-center p-3 text-white cc">
	&copy 2024 Copyright: Coded By Soe Aung &nbsp;
	<a href="https://www.youtube.com/"><img src="img/fb.jpg" width="20px"></a>
	</div>

</body>

<style>
    body{
        background-color:#1F2739;
    }

.yu{
    color: #19DBD2;
}

.cc{
    text-align: center;
    background-color: skyblue;
}
</style>