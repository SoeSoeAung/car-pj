<center>

<div class="row">
            <div class="header-buttons">
               
               <a href="waterwash.php" id="addButton2" class="cool2">< Back </a>
               
           </div>
        <div class="col-5 cheat-center">
        &nbsp;<br>
        <img src="img/pro.jpg" width="450" style="margin-left:200px;
       border-radius: 20px; margin-top: 20px; " />
        </div>
        <div class="col-1"></div>
        <div class="col-5">      
             <div class="container">
        <div class="header">
            <h1 style="color:#28a745">Booking Form</h1>
        </div>


        <?php
    error_reporting(1);
    include('connection.php');
    if(isset($_POST['sub'])) {
        $car_name = $_POST['cname'];
        $phone = $_POST['phone'];  
        $name = $_POST['name'];
        $car_price = $_POST['price'];
        $address = $_POST['add'];

        // Enclose `order` table name in backticks
        $query = "INSERT INTO `booking` VALUES ('', '$name', '$phone', '$address', '$car_name', '$car_price')";
        $con->query($query);
        echo "<script>window.location.href = 'bookingsuccess.php'</script>";   
    }
?>
        
        <div>
            <form method="POST" enctype="multipart/form-data">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required><br><br>

                <label for="name">Car_Name:</label>
                <input type="text" id="name" name="cname"
                value="<?php echo $_GET['name'] ?>" readonly
                required><br><br>

                <label for="price">Price:</label>
                <input type="text" id="price" name="price"
                value="<?php echo $_GET['price'] ?>"  readonly
                required><br><br>

                <label for="mail">Phone:</label>
                <input type="text" name="phone" required><br><br>

                <label for="add">Address:</label>
                <textarea id="description" name="add" required></textarea><br><br>
                
                <button type="submit" name="sub">Submit</button>
            </form>
        </div>
    </div></div>

</center>

<style>
body{
        background-color:#1F2739;
    }

    .cool2 {
    display: inline-block;
    background-color: skyblue;
    color: white; /* White text */
    text-decoration: none; /* Remove underline */
    padding: 10px 20px; /* Padding around text */
    border-radius: 5px; /* Rounded corners */
    font-size: 16px; /* Font size */
    font-weight: bold; /* Make text bold */
    margin-left:1000px;
}

.cool2:hover {
    background-color: cyan; /* Darker green on hover */
    color:white !important;
}
</style>