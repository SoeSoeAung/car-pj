<body>
<center><br>

<div class="row">
    <div class="col-1"></div>
    <div class="col-3">
    &nbsp;
    
    <a href="home.html" class="cool">< Back </a></div>
    <div>
        <div class="col-3"></div>
       
        <h1 class="www">OIL_List</h1>
        
    </div>
    <div class="col-2"></div>
    &nbsp;
        <a href="add-oil_list.php" class="cool2">+ Add New OIL</a>
    <div><br><br>
   
    </div>
  



  
  </div>

<table class="sss">
    <thead class="ll">
        <tr>
            <th><h3>No</h3></th>
            <th><h3>Name</h3></th>
            <th><h3>Price</h3></th>
            <th><h3>Des</h3></th>
            <th><h3>Image</h3></th>
            <th colspan="2"><h3>Action</h3></th>
        </tr>
    </thead>
    <tbody>

   
    <?php
    include("connection.php");
    error_reporting(1);
    $data = "SELECT * FROM oil_list ORDER BY id DESC";
$val = $con->query($data);
$i = 1;
if ($val->num_rows > 0) {
    while (list($id, $name, $price, $image, $des) = mysqli_fetch_array($val)) {
        echo "<tr>";
        echo "<td>".$i++."</td>"; 
        echo "<td>".$name."</td><td>".$price."</td><td>".$des."</td>";
       
        echo "<td><img src='img/$image' width='100' class='rounded-circle' /></td>";
        echo "<td><a href='delete-oil_list.php?id=$id&img=$img'><img src='img/de.jpg' style='border-radius:20px; margin-left:-20px' width='80'/></a></td>";
        echo "<td><a href='edit-oil_list.php?id=$id'><img src='img/editf.webp' style='border-radius:20px; margin-left:-20px' width='80'/></a></td>";
       
        echo "</tr>";
    }
} else {
    echo "<tr><td class='text-center'><b>No data available</b></td></tr>";
}

    ?>

    </tbody>
</table>

</center>

</body>

<style>
    body{
        background-color:#1F2739;
    }


.cool{
    display: inline-block;
    background-color: #28a745; /* Green background */
    color: white; /* White text */
    text-decoration: none; /* Remove underline */
    padding: 10px 20px; /* Padding around text */
    border-radius: 5px; /* Rounded corners */
    font-size: 16px; /* Font size */
    font-weight: bold; /* Make text bold */
    margin-right:1000px;
}

.cool:hover {
    background-color: green; /* Darker green on hover */
    color:white !important;
}

.cool2 {
    display: inline-block;
    background-color: skyblue;
    color: white; /* White text */
    text-decoration: none; /* Remove underline */
    padding: 10px 20px; /* Padding around text */
    border-radius: 5px; /* Rounded corners */
    font-size: 16px; /* Font size */
    font-weight: bold; /* Make text bold */
    margin-left:1000px;
}

.cool2:hover {
    background-color: cyan; /* Darker green on hover */
    color:white !important;
}

.sss {
	  text-align: center;
      vertical-align: middle;
	  overflow: hidden;
	  width: 80%;
	  margin: 0 auto;
  display: table;
  padding: 0 0 8em 0;
}

.sss td, .sss th {
	  padding-bottom: 2%;
	  padding-top: 2%;
  padding-left:2%;  
}




/* Background-color of the even rows */
.sss tr:nth-child(even) {
	  background-color: #2C3446;
}

.sss td {
	  background-color: #2C3446;
}


.sss tr:hover {
-webkit-box-shadow: 0 6px 6px -6px #0E1119;
	   -moz-box-shadow: 0 6px 6px -6px #0E1119;
	        box-shadow: 0 6px 6px -6px #0E1119;
}

.sss td:hover {
  background-color: #19DBD2;
  color: #403E10;
  font-weight: bold;
  
  
  
  transition-delay: 0s;
	  transition-duration: 0.4s;
	  transition-property: all;
  transition-timing-function: line;
}

.www{
    color: #19DBD2;
}

.rew{
    color: #19DBD2;
}

.ll{
    color:#E11371;
}


</style>