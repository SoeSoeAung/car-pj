<html>
<head>
	<title>Waterwash Car Menu</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<div class="row container">
    <div class="col-4 cheat-center">
        &nbsp;<br><br><br><br><center>
        <img src="img/man.jpg" width="450" style="margin-left:450px;
       border-radius: 20px; margin-top: 20px; "/></center>
    </div>
        <div class="col-1"></div>
    <div class="col-5">      
             <div class="container">
            </div>
            <h1 class="iop"><i>Add Waterwash-car</i></h1>
            
            <div style="margin-left:px">
               
                <a href="waterwash.php" class="cool"> Back </a>
                
            </div>
    </div>


    <?php
    error_reporting(1);
    include("connection.php");

    if(isset($_POST['sub'])) {
        $car_name = $_POST['name'];
        $car_price = $_POST['price'];
        $image = $_FILES['img']['name'];
        $time = $_POST['time'];

        $query=mysqli_query($con, "insert into waterwash(Name,Price,Img,Time) value('$car_name','$car_price','$image','$time')");
        
        if ($query) {
            move_uploaded_file($_FILES["img"]["tmp_name"], "img/".$image);
            echo "<script>alert('Waterwash-car has been added');</script>";
            echo "<script>window.location.href='waterwash.php'</script>";
        } else {
            echo "<script>alert('Something wrong. Please try again.');</script>";
        }
    }
?>

    
        <div class="row container mt-5">
            <form method="post" enctype="multipart/form-data">
            <label>Name:</label>
            <input type="text" name="name" required/><br><br>

            <label>Price:</label>
            <input type="text" name="price" required/><br><br>

            <label>Image:</label>
            <input type="file" name="img" required/><br><br>

            <label>Time:</label>
            <input type="text" name="time" required/><br><br>

            <input type="submit" value="Submit" name="sub" />

            </form>
        </div>
    
</div>


        

</body>

</html>

<style>
 body{
        background-color:#1F2739;
}

.cool{
    display: inline-block;
    background-color: #28a745; /* Green background */
    color: white; /* White text */
    text-decoration: none; /* Remove underline */
    padding: 10px 20px; /* Padding around text */
    border-radius: 5px; /* Rounded corners */
    font-size: 16px; /* Font size */
    font-weight: bold; /* Make text bold */
    margin-left: 700px;
}

.cool:hover {
    background-color: green; /* Darker green on hover */
    color:white !important;
}



.iop{
    color: #19DBD2;
}

.container{
    text-align:center;
    vertical-align:middle;
    color:#19DBD2;
}



label {
    display: block;
    margin-bottom: 5px;
    text-align:center;
}

</style>