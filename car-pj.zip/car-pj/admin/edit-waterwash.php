<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<body>


<div class="row">
    <div class="col-1"></div>
    <div class="col-3">
    &nbsp;
    
    <a href="home.html" class="cool"> Back </a></div>
    <div>
        <div class="col-3"></div>
        <h1 class="www"><i>Edit Waterwash Form</i></h1>
        
        
    </div>
</div>
<br><br><br>
<div>
    <img src="img/ccc.jpg" width="400px" alt="image" style="border-radius: 20px;" />
</div>
<br><br><br>


<?php
include("connection.php");
extract($_POST);
error_reporting(1);
$id = $_GET['id'];
$q = "select * from waterwash where id=$id";
$data = $con->query($q);
$final = mysqli_fetch_array($data);
if($sub){
    $q="update waterwash set Name='$name',Price='$price',Time='$time' where id=$id";
    $con->query($q);
    header('location:waterwash.php');
}
?>

<form method="post" class="www">
    <label>Name:</label>
    <input type="text" name="name" value="<?php echo $final['Name']?>"/><br><br>

    <label>Price:</label>
    <input type="text" name="price" value="<?php echo $final['Price']?>"/><br><br>


    <label>Time:</label>
    <input type="text" name="time" value="<?php echo $final['Time']?>"/><br><br>

    <input type="submit" value="Update" role="button" name="sub" class="btn btn-outline-info" />


</form>

</body>

<style>
body{
    font-family: Arial, sans-serif;
    background-color: #1f2739; /* Dark blue background */
    color: #E5E5E5; /* Light grey text */
    overflow-x: hidden;
    text-align: center;
}

.cool{
    display: inline-block;
    background-color: #28a745; /* Green background */
    color: white; /* White text */
    text-decoration: none; /* Remove underline */
    padding: 10px 20px; /* Padding around text */
    border-radius: 5px; /* Rounded corners */
    font-size: 16px; /* Font size */
    font-weight: bold; /* Make text bold */
    margin-right:1000px;
}

.cool:hover {
    background-color: green; /* Darker green on hover */
    color:white !important;
}

.www{
    color: #19DBD2;
}

</style>