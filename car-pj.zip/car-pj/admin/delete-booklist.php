<?php
include("connection.php");
$q = "delete from `booklist` where id='{$_GET['id']}'";
$con->query($q);
header('location:booklist.php');
?>