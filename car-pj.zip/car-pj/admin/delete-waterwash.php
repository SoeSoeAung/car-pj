<?php
include("connection.php");
$q = "delete from `waterwash` where id='{$_GET['id']}'";
$con->query($q);
header('location:waterwash.php');
?>