<?php
include("connection.php");
$q = "delete from `rental_car` where id='{$_GET['id']}'";
$con->query($q);
unlink("img/{$_GET['img']}");
header('location:rental_car.php');
?>